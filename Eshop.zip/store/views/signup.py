from django.contrib.auth.hashers import make_password
from django.views import View
from django.shortcuts import render, redirect
from store.models.customer import Customer


class Signup(View):
    def get(self, request):
        return render(request, 'signup.html')

    def post(self, request):
        postData = request.POST
        first_name = postData.get('firstname')
        last_name = postData.get('lastname')
        mobile = postData.get('mobile')
        email = postData.get('email')
        password = postData.get('password')

        value = {
            'first_name': first_name,
            'last_name': last_name,
            'mobile': mobile,
            'email': email,
        }

        customer = Customer(first_name=first_name, last_name=last_name, mobile=mobile, email=email, password=password)

        error_message = self.validateCustomer(customer)

        # save
        if not error_message:
            print(first_name, last_name, mobile, email, password)
            customer.password = make_password(customer.password)
            customer.register()
            return redirect('homepage')
        else:
            data = {
                'error': error_message,
                'values': value
            }
            return render(request, 'signup.html', data)

    def validateCustomer(self, customer):
        error_message = None
        if not customer.first_name:
            error_message = "First Name Required !!"
        elif len(customer.first_name) < 3:
            error_message = "First Name must be 3 char long"
        elif not customer.last_name:
            error_message = "Last Name Required !!"
        elif len(customer.last_name) < 3:
            error_message = "Last Name must be 3 char long"
        elif not customer.mobile:
            error_message = "Mobile number required !!"
        elif len(customer.mobile) < 10:
            error_message = "mobile number must be 10 number long"
        elif not customer.email:
            error_message = "email required !!"
        elif len(customer.email) < 11:
            error_message = "email must be min 11 char"
        elif not customer.password:
            error_message = "Password required !!"
        elif len(customer.password) < 6:
            error_message = "password must be min 6 char"
        elif customer.isCustomerExist():
            error_message = 'Email already registered'

        return error_message
